<template>
  <div>
    <h1 style="text-align: center;padding-top: 10%">还木有写</h1>
  </div>
</template>
<script>
export default {
  name: 'reportManager',
  data() {
    return {

    }
  },
  mounted() {

  }
  ,
  methods: {

  }
}
</script>
<style>

</style>